<div class="dashboard-footer">
    <div class="flex-center flex-wrap gap-16">
        <p class="text-gray-300 text-13 fw-normal"> &copy; Copyright {{$ins_name}} 2025, All Right Reserverd</p>
        
    </div>
</div>